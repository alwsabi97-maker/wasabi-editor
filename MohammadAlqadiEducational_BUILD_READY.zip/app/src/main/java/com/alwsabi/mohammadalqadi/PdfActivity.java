package com.alwsabi.mohammadalqadi;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.view.*;
import android.widget.*;
import java.io.*;

public class PdfActivity extends Activity {
    PdfRenderer renderer; LinearLayout root; TextView pageTitle; int page=0;
    @Override public void onCreate(Bundle b){super.onCreate(b);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);pageTitle=new TextView(this);pageTitle.setGravity(Gravity.CENTER);pageTitle.setTextSize(16);root.addView(pageTitle,new LinearLayout.LayoutParams(-1,52));setContentView(root);try{File f=new File(getIntent().getStringExtra("path"));renderer=new PdfRenderer(ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY));showPage(0);}catch(Exception e){pageTitle.setText("تعذر فتح الملف");}}
    void showPage(int p){if(renderer==null)return;page=p;while(root.getChildCount()>1)root.removeViewAt(1);pageTitle.setText(getIntent().getStringExtra("title")+"  •  صفحة "+(p+1)+" / "+renderer.getPageCount());PdfRenderer.Page pg=renderer.openPage(p);Bitmap bm=Bitmap.createBitmap(pg.getWidth(),pg.getHeight(),Bitmap.Config.ARGB_8888);pg.render(bm,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);pg.close();ScrollView sv=new ScrollView(this);ImageView im=new ImageView(this);im.setImageBitmap(bm);im.setAdjustViewBounds(true);sv.addView(im);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));LinearLayout nav=new LinearLayout(this);Button prev=new Button(this);prev.setText("السابق");Button next=new Button(this);next.setText("التالي");nav.addView(prev,new LinearLayout.LayoutParams(0,58,1));nav.addView(next,new LinearLayout.LayoutParams(0,58,1));root.addView(nav);prev.setOnClickListener(v->{if(page>0)showPage(page-1);});next.setOnClickListener(v->{if(page<renderer.getPageCount()-1)showPage(page+1);});}
    @Override protected void onDestroy(){if(renderer!=null)try{renderer.close();}catch(Exception ignored){}super.onDestroy();}
}
