package com.alwsabi.mohammadalqadi;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import android.util.Base64;

public class MainActivity extends Activity {
    static final String GREEN="#0B6B5B", DARK="#063D35", GOLD="#C99B3B", BG="#F5F8F7", TEXT="#18322D";
    static final String[] GRADES={"الأول الثانوي","الثاني الثانوي","الثالث الثانوي"};
    static final String[] SUBJECTS={"الكيمياء","الفيزياء","الأحياء"};
    SharedPreferences sp; LinearLayout body; TextView title; String studentCode="", studentName="";
    ArrayList<Material> materials=new ArrayList<>(); ArrayList<Question> questions=new ArrayList<>(); ArrayList<Score> scores=new ArrayList<>(); HashSet<String> codes=new LinkedHashSet<>();
    int pdfRequest=1001, photoRequest=1002;

    @Override public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("mqa_data",MODE_PRIVATE); loadAll(); studentCode=sp.getString("current_code",""); studentName=sp.getString("current_name",""); showHome();}

    TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.parseColor(TEXT));t.setPadding(20,18,20,18);return t;}
    TextView center(String s,int size){TextView t=text(s,size);t.setGravity(Gravity.CENTER);return t;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(Color.parseColor(GREEN));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,60);p.setMargins(8,6,8,6);b.setLayoutParams(p);return b;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(16);e.setPadding(18,10,18,10);return e;}

    void base(String heading){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.parseColor(BG));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(Color.parseColor(DARK));
        title=center(heading,20);title.setTextColor(Color.WHITE);bar.addView(title,new LinearLayout.LayoutParams(0,64,1));
        root.addView(bar);
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(10,10,10,18);ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setBackgroundColor(Color.parseColor(DARK));String[] n={"الرئيسية","المكتبة","الاختبارات","الأستاذ","المعلم"};
        for(String x:n){Button q=new Button(this);q.setText(x);q.setTextColor(Color.WHITE);q.setTextSize(11);q.setAllCaps(false);q.setBackgroundColor(Color.parseColor(DARK));nav.addView(q,new LinearLayout.LayoutParams(0,58,1));
            if(x.equals("الرئيسية"))q.setOnClickListener(v->showHome()); else if(x.equals("المكتبة"))q.setOnClickListener(v->showMaterials()); else if(x.equals("الاختبارات"))q.setOnClickListener(v->showTests()); else if(x.equals("الأستاذ"))q.setOnClickListener(v->showProfile()); else q.setOnClickListener(v->teacherLogin()); }
        root.addView(nav);setContentView(root);
    }

    void showHome(){base("برنامج محمد القاضي التعليمي العلمي");
        TextView hero=center("التعليم للجميع",27);hero.setTextColor(Color.parseColor(GREEN));body.addView(hero);
        body.addView(center("منصة علمية متخصصة في الكيمياء والفيزياء والأحياء\nللصفوف الأول والثاني والثالث الثانوي",17));
        if(studentCode.isEmpty()){Button b=button("دخول الطالب بالكود");body.addView(b);b.setOnClickListener(v->studentLogin());}
        else {TextView u=center("مرحبًا: "+studentName+"\nالكود: "+studentCode,17);body.addView(u);Button out=button("تسجيل خروج الطالب");body.addView(out);out.setOnClickListener(v->{studentCode="";studentName="";sp.edit().remove("current_code").remove("current_name").apply();showHome();});}
        Button lib=button("📚 المكتبة العلمية");body.addView(lib);lib.setOnClickListener(v->showMaterials());
        Button test=button("📝 الاختبارات المباشرة");body.addView(test);test.setOnClickListener(v->showTests());
        Button prof=button("👨‍🏫 عن الأستاذ والبرنامج");body.addView(prof);prof.setOnClickListener(v->showProfile());
        TextView note=center("يعمل التطبيق دون إنترنت بعد تثبيته وإضافة المحتوى من المعلم.",14);note.setTextColor(Color.DKGRAY);body.addView(note);
    }

    void studentLogin(){EditText e=input("كود الطالب");e.setInputType(InputType.TYPE_CLASS_TEXT);new AlertDialog.Builder(this).setTitle("دخول الطالب").setMessage("لكل طالب كود مستقل يضيفه المعلم.").setView(e).setPositiveButton("متابعة",(d,w)->{String c=e.getText().toString().trim();if(!codes.contains(c)){toast("هذا الكود غير موجود أو غير مضاف من المعلم.");return;}String n=sp.getString("name_"+enc(c),"");if(n.isEmpty())askName(c);else setStudent(c,n);}).setNegativeButton("إلغاء",null).show();}
    void askName(String c){EditText e=input("اسم الطالب الرباعي أو الكامل");new AlertDialog.Builder(this).setTitle("تسجيل الطالب لأول مرة").setView(e).setPositiveButton("حفظ",(d,w)->{String n=e.getText().toString().trim();if(n.length()<2){toast("اكتب اسمًا صحيحًا.");return;}sp.edit().putString("name_"+enc(c),n).apply();setStudent(c,n);}).setNegativeButton("إلغاء",null).show();}
    void setStudent(String c,String n){studentCode=c;studentName=n;sp.edit().putString("current_code",c).putString("current_name",n).apply();showHome();}

    void showMaterials(){base("المكتبة العلمية");if(studentCode.isEmpty()){body.addView(center("سجل الدخول أولًا بكود الطالب لعرض الملازم والكتب.",18));return;}if(materials.isEmpty()){body.addView(center("لا توجد ملازم أو كتب مضافة حاليًا.\nيمكن للمعلم إضافتها من لوحة المعلم.",17));return;}
        for(Material m:materials){Button b=button("📘 "+m.title+"\n"+m.grade+" • "+m.subject);body.addView(b);b.setOnClickListener(v->openPdf(m));}
    }
    void openPdf(Material m){try{File f=decryptToTemp(m.path);Intent i=new Intent(this,PdfActivity.class);i.putExtra("path",f.getAbsolutePath());i.putExtra("title",m.title);startActivity(i);}catch(Exception e){toast("تعذر فتح الكتاب. قد يكون الملف تالفًا أو رمز المعلم تغيّر.");}}

    void showTests(){base("الاختبارات المباشرة");if(studentCode.isEmpty()){body.addView(center("سجل دخول الطالب أولًا.",18));return;}if(questions.isEmpty()){body.addView(center("لا توجد أسئلة مضافة بعد.\nيمكن للمعلم بناء بنك الأسئلة من لوحة المعلم.",17));return;}
        for(String g:GRADES)for(String s:SUBJECTS){int n=countQuestions(g,s);if(n>0){Button b=button("اختبار "+s+" • "+g+"\n"+n+" سؤال");body.addView(b);b.setOnClickListener(v->takeTest(g,s));}}
        body.addView(text("سجل نتائجك",20));ArrayList<Score> mine=new ArrayList<>();for(Score z:scores)if(z.code.equals(studentCode))mine.add(z);
        if(mine.isEmpty())body.addView(center("لم تحفظ نتائج بعد.",16));else for(Score z:mine){TextView t=text("• "+z.subject+" — "+z.grade+"\nالنتيجة: "+z.correct+" / "+z.total+"\n"+z.time,15);body.addView(t);}
    }
    int countQuestions(String g,String s){int n=0;for(Question q:questions)if(q.grade.equals(g)&&q.subject.equals(s))n++;return n;}

    void takeTest(String g,String s){ArrayList<Question> qs=new ArrayList<>();for(Question q:questions)if(q.grade.equals(g)&&q.subject.equals(s))qs.add(q);Collections.shuffle(qs);final ArrayList<RadioGroup> groups=new ArrayList<>();
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);TextView intro=center("اختبار "+s+" — "+g+"\nاختر إجابة واحدة لكل سؤال.",18);box.addView(intro);
        int num=1;for(Question q:qs){box.addView(text(num+". "+q.text,17));RadioGroup rg=new RadioGroup(this);for(String o:q.options){if(o.trim().isEmpty())continue;RadioButton r=new RadioButton(this);r.setText(o);r.setTextSize(16);rg.addView(r);}groups.add(rg);box.addView(rg);num++;}
        ScrollView sv=new ScrollView(this);sv.addView(box);new AlertDialog.Builder(this).setTitle("بدء الاختبار").setView(sv).setPositiveButton("تصحيح وحفظ",(d,w)->{int score=0;for(int i=0;i<qs.size();i++){RadioGroup rg=groups.get(i);if(rg.getCheckedRadioButtonId()!=-1){RadioButton r=rg.findViewById(rg.getCheckedRadioButtonId());if(r.getText().toString().equals(qs.get(i).correct))score++;}}String stamp=new Date().toString();scores.add(new Score(studentCode,studentName,g,s,score,qs.size(),stamp));saveScores();toast("تم حفظ النتيجة: "+score+" / "+qs.size());showTests();}).setNegativeButton("إلغاء",null).show();
    }

    void showProfile(){base("الأستاذ محمد القاضي");String photo=sp.getString("teacher_photo","");if(!photo.isEmpty()){ImageView im=new ImageView(this);im.setImageURI(Uri.fromFile(new File(photo)));im.setAdjustViewBounds(true);body.addView(im,new LinearLayout.LayoutParams(-1,260));}
        body.addView(center("الأستاذ محمد القاضي",25));body.addView(center("أستاذ الكيمياء والفيزياء والأحياء\nمدرسة النور الأساسية الثانوية بالروحاء — وصاب السافل",16));
        body.addView(text("المؤهل العلمي\nبكالوريوس تربية — تخصص كيمياء فيزيائية\n\nمجالات التدريس\nالكيمياء • الفيزياء • الأحياء\n\nرسالة البرنامج\nتقديم محتوى علمي منظم يجمع الكتب والملازم والاختبارات في بيئة واحدة، ويتيح للطالب التعلم والمراجعة وقياس تقدمه دون الحاجة إلى اتصال بالإنترنت.\n\nالهاتف: 774470090\nالبريد الإلكتروني: alwsabi97@gmail.com\n\nرؤية تعليمية\nدعم الطالب والمعلم بأداة سهلة ومنظمة، وتشجيع التعلم الذاتي والمراجعة المستمرة، مع حفظ نتائج الاختبارات محليًا على الجهاز.",17));
    }

    void teacherLogin(){EditText e=input("رمز المعلم");e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);String h=sp.getString("teacher_hash","");
        if(h.isEmpty()) new AlertDialog.Builder(this).setTitle("إعداد رمز المعلم").setMessage("هذه أول مرة. اختر رمزًا سريًا من 6 أرقام أو أكثر، ولا تعطه للطلاب.").setView(e).setPositiveButton("حفظ",(d,w)->{String p=e.getText().toString().trim();if(p.length()<6){toast("الرمز يجب أن يكون 6 أرقام أو أكثر.");return;}sp.edit().putString("teacher_hash",sha(p)).apply();showTeacher();}).setNegativeButton("إلغاء",null).show();
        else new AlertDialog.Builder(this).setTitle("دخول المعلم").setView(e).setPositiveButton("دخول",(d,w)->{if(sha(e.getText().toString()).equals(sp.getString("teacher_hash","")))showTeacher();else toast("رمز المعلم غير صحيح.");}).setNegativeButton("إلغاء",null).show();
    }

    void showTeacher(){base("لوحة المعلم الخاصة");body.addView(center("منطقة إدارة خاصة بالمعلم\nالملفات والأسئلة والأكواد محفوظة محليًا.",16));
        Button b=button("➕ إضافة كود طالب");body.addView(b);b.setOnClickListener(v->addCode());
        b=button("📚 إضافة ملزمة أو كتاب PDF مشفّر");body.addView(b);b.setOnClickListener(v->pickPdf());
        b=button("📝 إضافة سؤال جديد");body.addView(b);b.setOnClickListener(v->addQuestion());
        b=button("👤 إدارة الطلاب والدرجات");body.addView(b);b.setOnClickListener(v->showStudentRecords());
        b=button("🖼 إضافة/تغيير صورة الأستاذ");body.addView(b);b.setOnClickListener(v->pickPhoto());
        b=button("🔐 تغيير رمز المعلم");body.addView(b);b.setOnClickListener(v->changeTeacherPin());
        b=button("📦 معلومات التخزين");body.addView(b);b.setOnClickListener(v->showStorageInfo());
    }

    void addCode(){EditText e=input("كود فريد مثل MQA-1001");new AlertDialog.Builder(this).setTitle("إضافة كود طالب").setView(e).setPositiveButton("إضافة",(d,w)->{String c=e.getText().toString().trim();if(c.length()<4){toast("الكود قصير.");return;}if(codes.contains(c)){toast("الكود موجود مسبقًا.");return;}codes.add(c);saveAll();toast("تمت إضافة الكود.");}).setNegativeButton("إلغاء",null).show();}

    void pickPdf(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/pdf");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,pdfRequest);}
    void pickPhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,photoRequest);}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(c!=RESULT_OK||data==null)return;if(r==photoRequest){try{File out=new File(getFilesDir(),"teacher_photo.jpg");copyUriInternal(data.getData(),out);sp.edit().putString("teacher_photo",out.getAbsolutePath()).apply();toast("تم حفظ صورة الأستاذ.");showTeacher();}catch(Exception e){toast("تعذر حفظ الصورة.");}}else if(r==pdfRequest){addPdfDetails(data.getData());}}
    void addPdfDetails(Uri uri){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText title=input("اسم الملزمة أو الكتاب");Spinner g=spinner(GRADES),s=spinner(SUBJECTS);l.addView(title);l.addView(label("الصف"));l.addView(g);l.addView(label("المادة"));l.addView(s);new AlertDialog.Builder(this).setTitle("بيانات الكتاب").setView(l).setPositiveButton("تشفير وحفظ",(d,w)->{try{String name=title.getText().toString().trim();if(name.isEmpty()){toast("اكتب اسم الملف.");return;}File out=new File(getFilesDir(),"pdf_"+System.currentTimeMillis()+".mqa");encryptUri(uri,out);materials.add(new Material(name,GRADES[g.getSelectedItemPosition()],SUBJECTS[s.getSelectedItemPosition()],out.getAbsolutePath()));saveAll();toast("تمت إضافة الكتاب وتشفيره داخل التطبيق.");}catch(Exception e){toast("فشل تشفير الملف.");}}).setNegativeButton("إلغاء",null).show();}

    void addQuestion(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);Spinner g=spinner(GRADES),s=spinner(SUBJECTS);EditText q=input("نص السؤال");EditText[] o={input("الخيار الأول"),input("الخيار الثاني"),input("الخيار الثالث"),input("الخيار الرابع")};Spinner correct=new Spinner(this);String[] labels={"الخيار الأول","الخيار الثاني","الخيار الثالث","الخيار الرابع"};ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);correct.setAdapter(a);
        l.addView(label("الصف"));l.addView(g);l.addView(label("المادة"));l.addView(s);l.addView(q);for(EditText x:o)l.addView(x);l.addView(label("الإجابة الصحيحة"));l.addView(correct);
        new AlertDialog.Builder(this).setTitle("إضافة سؤال").setView(l).setPositiveButton("حفظ",(d,w)->{String[] opts=new String[4];for(int i=0;i<4;i++)opts[i]=o[i].getText().toString().trim();if(q.getText().toString().trim().isEmpty()||opts[0].isEmpty()||opts[1].isEmpty()){toast("أدخل السؤال وخيارين على الأقل.");return;}Question z=new Question(GRADES[g.getSelectedItemPosition()],SUBJECTS[s.getSelectedItemPosition()],q.getText().toString().trim(),opts,opts[correct.getSelectedItemPosition()]);questions.add(z);saveAll();toast("تم حفظ السؤال.");}).setNegativeButton("إلغاء",null).show();}

    Spinner spinner(String[] vals){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,vals);s.setAdapter(a);return s;}
    TextView label(String s){TextView t=text(s,14);t.setTextColor(Color.parseColor(GREEN));return t;}

    void showStudentRecords(){StringBuilder x=new StringBuilder();if(codes.isEmpty())x.append("لا توجد أكواد طلاب بعد.");else for(String c:codes){x.append("الكود: ").append(c).append("\nالاسم: ").append(sp.getString("name_"+enc(c),"لم يسجل بعد")).append("\n");for(Score z:scores)if(z.code.equals(c))x.append("  • ").append(z.subject).append(" — ").append(z.grade).append(": ").append(z.correct).append('/').append(z.total).append("\n");x.append("\n");}new AlertDialog.Builder(this).setTitle("سجل الطلاب والدرجات").setMessage(x.toString()).setPositiveButton("إغلاق",null).show();}
    void changeTeacherPin(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText old=input("الرمز الحالي");old.setInputType(2);EditText neu=input("الرمز الجديد — 6 أرقام أو أكثر");neu.setInputType(2);l.addView(old);l.addView(neu);
        new AlertDialog.Builder(this).setTitle("تغيير رمز المعلم").setView(l).setPositiveButton("تغيير",(d,w)->{
            String oldHash=sha(old.getText().toString()), newPin=neu.getText().toString().trim();
            if(!oldHash.equals(sp.getString("teacher_hash",""))){toast("الرمز الحالي غير صحيح.");return;}
            if(newPin.length()<6){toast("الرمز الجديد قصير.");return;}
            String newHash=sha(newPin);
            try{
                for(Material m:materials){File f=new File(m.path);if(!f.exists())continue;byte[] plain=decryptBytes(f,oldHash);encryptBytes(plain,f,newHash);}
                sp.edit().putString("teacher_hash",newHash).apply();
                toast("تم تغيير رمز المعلم وإعادة تشفير الكتب الحالية.");
            }catch(Exception ex){toast("تعذر تغيير الرمز لأن أحد الملفات المشفرة تالف.");}
        }).setNegativeButton("إلغاء",null).show();
    }
    void showStorageInfo(){long size=0;for(Material m:materials){File f=new File(m.path);if(f.exists())size+=f.length();}new AlertDialog.Builder(this).setTitle("حالة التخزين").setMessage("الملازم المشفرة: "+materials.size()+"\nالأسئلة: "+questions.size()+"\nأكواد الطلاب: "+codes.size()+"\nحجم ملفات الكتب المشفرة: "+(size/1024/1024)+" MB\n\nكل هذه البيانات محفوظة محليًا داخل التطبيق.").setPositiveButton("إغلاق",null).show();}

    void encryptUri(Uri uri,File out)throws Exception{InputStream in=getContentResolver().openInputStream(uri);byte[] data=readAll(in);encryptBytes(data,out,sp.getString("teacher_hash",""));}
    void encryptBytes(byte[] data,File out,String seed)throws Exception{byte[] iv=new byte[12];new SecureRandom().nextBytes(iv);SecretKey k=keyFor(seed);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,k,new GCMParameterSpec(128,iv));byte[] enc=cipher.doFinal(data);FileOutputStream f=new FileOutputStream(out);f.write(iv);f.write(enc);f.close();}
    File decryptToTemp(String path)throws Exception{byte[] dec=decryptBytes(new File(path),sp.getString("teacher_hash",""));File out=new File(getCacheDir(),"view_"+System.currentTimeMillis()+".pdf");writeAll(out,dec);return out;}
    byte[] decryptBytes(File file,String seed)throws Exception{byte[] all=readAll(file);if(all.length<13)throw new IOException("bad encrypted file");byte[] iv=Arrays.copyOfRange(all,0,12),enc=Arrays.copyOfRange(all,12,all.length);SecretKey k=keyFor(seed);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,k,new GCMParameterSpec(128,iv));return cipher.doFinal(enc);}
    SecretKey keyFor(String seed)throws Exception{byte[] salt=shaBytes("mqa-salt-"+seed);PBEKeySpec spec=new PBEKeySpec(seed.toCharArray(),salt,120000,256);SecretKeyFactory f=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");return new SecretKeySpec(f.generateSecret(spec).getEncoded(),"AES");}

    void saveAll(){saveCodes();saveMaterials();saveQuestions();saveScores();}
    void saveCodes(){StringBuilder b=new StringBuilder();for(String c:codes){if(b.length()>0)b.append('\n');b.append(enc(c));}sp.edit().putString("codes",b.toString()).apply();}
    void saveMaterials(){StringBuilder b=new StringBuilder();for(Material m:materials)b.append(enc(m.title)).append('|').append(enc(m.grade)).append('|').append(enc(m.subject)).append('|').append(enc(m.path)).append('\n');sp.edit().putString("materials",b.toString()).apply();}
    void saveQuestions(){StringBuilder b=new StringBuilder();for(Question q:questions){b.append(enc(q.grade)).append('|').append(enc(q.subject)).append('|').append(enc(q.text)).append('|');for(int i=0;i<4;i++){if(i>0)b.append('~');b.append(enc(q.options[i]));}b.append('|').append(enc(q.correct)).append('\n');}sp.edit().putString("questions",b.toString()).apply();}
    void saveScores(){StringBuilder b=new StringBuilder();for(Score z:scores)b.append(enc(z.code)).append('|').append(enc(z.name)).append('|').append(enc(z.grade)).append('|').append(enc(z.subject)).append('|').append(z.correct).append('|').append(z.total).append('|').append(enc(z.time)).append('\n');sp.edit().putString("scores",b.toString()).apply();}
    void loadAll(){codes.clear();materials.clear();questions.clear();scores.clear();String c=sp.getString("codes","");for(String line:c.split("\\n"))if(!line.trim().isEmpty())codes.add(dec(line));String m=sp.getString("materials","");for(String line:m.split("\\n")){String[]p=line.split("\\|",-1);if(p.length==4)materials.add(new Material(dec(p[0]),dec(p[1]),dec(p[2]),dec(p[3])));}String q=sp.getString("questions","");for(String line:q.split("\\n")){String[]p=line.split("\\|",-1);if(p.length==6){String[]op=p[3].split("~",-1);String[]oo=new String[]{op.length>0?dec(op[0]):"",op.length>1?dec(op[1]):"",op.length>2?dec(op[2]):"",op.length>3?dec(op[3]):""};questions.add(new Question(dec(p[0]),dec(p[1]),dec(p[2]),oo,dec(p[5])));}}String sc=sp.getString("scores","");for(String line:sc.split("\\n")){String[]p=line.split("\\|",-1);if(p.length==7){try{scores.add(new Score(dec(p[0]),dec(p[1]),dec(p[2]),dec(p[3]),Integer.parseInt(p[4]),Integer.parseInt(p[5]),dec(p[6])));}catch(Exception ignored){}}}}

    static String enc(String s){return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);}static String dec(String s){try{return new String(Base64.decode(s,Base64.NO_WRAP),StandardCharsets.UTF_8);}catch(Exception e){return "";}}
    static byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);in.close();return b.toByteArray();}static byte[] readAll(File f)throws IOException{return readAll(new FileInputStream(f));}static void writeAll(File f,byte[] b)throws IOException{FileOutputStream o=new FileOutputStream(f);o.write(b);o.close();}void copyUriInternal(Uri u,File out)throws IOException{InputStream in=getContentResolver().openInputStream(u);FileOutputStream o=new FileOutputStream(out);byte[]b=new byte[8192];int n;while((n=in.read(b))!=-1)o.write(b,0,n);in.close();o.close();}
    static String sha(String s){return hex(shaBytes(s));}static byte[] shaBytes(String s){try{return MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));}catch(Exception e){return new byte[32];}}static String hex(byte[]b){StringBuilder x=new StringBuilder();for(byte v:b)x.append(String.format(Locale.US,"%02x",v));return x.toString();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    static class Material{String title,grade,subject,path;Material(String a,String b,String c,String d){title=a;grade=b;subject=c;path=d;}}
    static class Question{String grade,subject,text,correct;String[]options;Question(String g,String s,String t,String[]o,String c){grade=g;subject=s;text=t;options=o;correct=c;}}
    static class Score{String code,name,grade,subject,time;int correct,total;Score(String c,String n,String g,String s,int a,int b,String t){code=c;name=n;grade=g;subject=s;correct=a;total=b;time=t;}}
}
