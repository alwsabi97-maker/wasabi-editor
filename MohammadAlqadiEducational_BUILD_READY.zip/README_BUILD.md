# برنامج محمد القاضي التعليمي العلمي

مشروع Android أصلي مبني بـ Java وAndroid Gradle Plugin.

## البناء
- Java 17
- Android SDK 35
- Android Gradle Plugin 8.6.1
- Gradle 8.10.2
- لا توجد مكتبات خارجية مطلوبة للتطبيق نفسه.

يوجد سير عمل GitHub Actions في `.github/workflows/build-apk.yml` لبناء APK تلقائيًا.
